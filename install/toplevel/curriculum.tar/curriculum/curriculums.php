<?php
/*This is php code (lines are commented out using //). */
/*It is simply an array which must be edited*/
/*to record the installed curriculum packs. */

$curriculums=array(
	'1'=>'english_sixthform'
	,'2'=>'english_secondary'
//	,'3'=>'english_primary'
//	,'4'=>'spanish'
	);
?>

